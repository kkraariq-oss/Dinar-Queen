# دليل إعداد Firebase
## خطوات تفصيلية لإعداد قاعدة بيانات Firebase

---

## 1️⃣ إنشاء مشروع Firebase

### الخطوة 1: التسجيل والدخول
1. اذهب إلى [Firebase Console](https://console.firebase.google.com/)
2. قم بتسجيل الدخول بحساب Google الخاص بك
3. انقر على "Add project" أو "إضافة مشروع"

### الخطوة 2: إعداد المشروع
1. أدخل اسم المشروع: `dinar-coin` (أو أي اسم تريده)
2. اقبل شروط الخدمة
3. اختر ما إذا كنت تريد Google Analytics (اختياري)
4. انقر على "Create project"
5. انتظر حتى يتم إنشاء المشروع (قد يستغرق دقيقة)

---

## 2️⃣ إعداد Authentication

### الخطوة 1: تفعيل المصادقة
1. في القائمة الجانبية، انقر على "Authentication"
2. انقر على "Get started" إذا كانت أول مرة
3. اذهب إلى تبويب "Sign-in method"

### الخطوة 2: تفعيل Email/Password
1. انقر على "Email/Password"
2. فعّل الخيار الأول "Email/Password"
3. **لا تفعّل** "Email link (passwordless sign-in)" (إلا إذا أردت)
4. انقر على "Save"

---

## 3️⃣ إعداد Realtime Database

### الخطوة 1: إنشاء قاعدة البيانات
1. في القائمة الجانبية، انقر على "Realtime Database"
2. انقر على "Create Database"
3. اختر موقع الخادم:
   - اختر `us-central1` (أمريكا) أو الأقرب لك
4. اختر "Start in **test mode**" للتطوير
   - ⚠️ **ملاحظة**: في الإنتاج، يجب تحديث القواعد للأمان
5. انقر على "Enable"

### الخطوة 2: إعداد قواعد الأمان (للتطوير)
القواعد الافتراضية في Test Mode:
```json
{
  "rules": {
    ".read": "now < 1740960000000",
    ".write": "now < 1740960000000"
  }
}
```

### الخطوة 3: قواعد الأمان المقترحة (للإنتاج)
عند الاستعداد للنشر، استخدم هذه القواعد:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid == $uid",
        ".write": "auth != null && auth.uid == $uid",
        "balance": {
          ".validate": "newData.isNumber() && newData.val() >= 0"
        },
        "referralCode": {
          ".validate": "newData.isString() && newData.val().length == 10"
        }
      }
    },
    "transactions": {
      "$uid": {
        ".read": "auth != null && auth.uid == $uid",
        "$transactionId": {
          ".write": "auth != null && auth.uid == $uid && !data.exists()",
          ".validate": "newData.hasChildren(['type', 'amount', 'description', 'timestamp', 'status'])"
        }
      }
    },
    "purchase_requests": {
      "$uid": {
        ".read": "auth != null && (auth.uid == $uid || root.child('admins').child(auth.uid).exists())",
        "$requestId": {
          ".write": "auth != null && auth.uid == $uid && !data.exists()",
          ".validate": "newData.hasChildren(['userId', 'amount', 'totalIQD', 'status', 'timestamp'])"
        }
      }
    },
    "admins": {
      ".read": "auth != null",
      ".write": false
    }
  }
}
```

لتطبيق القواعد:
1. اذهب إلى Realtime Database > Rules
2. الصق القواعد أعلاه
3. انقر على "Publish"

---

## 4️⃣ الحصول على إعدادات Firebase

### الخطوة 1: فتح إعدادات المشروع
1. انقر على أيقونة الترس ⚙️ بجوار "Project Overview"
2. اختر "Project settings"

### الخطوة 2: إضافة تطبيق ويب
1. في قسم "Your apps"، انقر على أيقونة الويب `</>`
2. أدخل اسم التطبيق: `Dinar Coin Web`
3. **لا تحتاج** لتفعيل Firebase Hosting (إلا إذا أردت)
4. انقر على "Register app"

### الخطوة 3: نسخ الإعدادات
ستظهر لك إعدادات Firebase بهذا الشكل:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "dinar-coin.firebaseapp.com",
  databaseURL: "https://dinar-coin-default-rtdb.firebaseio.com",
  projectId: "dinar-coin",
  storageBucket: "dinar-coin.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef123456"
};
```

**انسخ هذه الإعدادات!** ستحتاجها في الخطوة التالية.

---

## 5️⃣ تحديث التطبيق

### الخطوة 1: فتح ملف JavaScript
افتح ملف `js/app.js` في محرر النصوص.

### الخطوة 2: استبدال الإعدادات
ابحث عن هذا الكود في بداية الملف:

```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY_HERE",
    authDomain: "YOUR_AUTH_DOMAIN_HERE",
    databaseURL: "YOUR_DATABASE_URL_HERE",
    projectId: "YOUR_PROJECT_ID_HERE",
    storageBucket: "YOUR_STORAGE_BUCKET_HERE",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID_HERE",
    appId: "YOUR_APP_ID_HERE"
};
```

استبدله بالإعدادات التي نسختها من Firebase Console.

### الخطوة 3: حفظ الملف
احفظ التغييرات في ملف `app.js`.

---

## 6️⃣ اختبار التطبيق

### الخطوة 1: رفع الملفات
ارفع جميع ملفات المشروع إلى خادم الويب أو GitHub Pages.

### الخطوة 2: فتح التطبيق
افتح التطبيق في المتصفح.

### الخطوة 3: التسجيل
1. انقر على "إنشاء حساب"
2. أدخل البيانات المطلوبة
3. انقر على "إنشاء الحساب"

### الخطوة 4: التحقق من قاعدة البيانات
1. ارجع إلى Firebase Console
2. اذهب إلى Realtime Database
3. يجب أن ترى البيانات التالية:
   - `users/{userId}/`
   - `transactions/{userId}/`

---

## 7️⃣ إضافة مسؤولين (Admin)

لإضافة حسابات مسؤولين للموافقة على طلبات الشراء:

### الخطوة 1: الحصول على User ID
1. سجل دخول بحساب المسؤول
2. افتح Console المتصفح (F12)
3. اكتب: `firebase.auth().currentUser.uid`
4. انسخ الـ UID

### الخطوة 2: إضافة المسؤول في Firebase
1. اذهب إلى Realtime Database
2. انقر على "+" بجوار الجذر
3. أضف:
   - Key: `admins/{userId}`
   - Value: `true`

---

## 8️⃣ نصائح مهمة

### للأمان 🔒
1. **لا تشارك** إعدادات Firebase علناً
2. استخدم قواعد الأمان المناسبة
3. فعّل reCAPTCHA للحماية من الروبوتات
4. راقب الاستخدام في Firebase Console

### للأداء ⚡
1. استخدم Indexes للبحث السريع
2. قلل عدد القراءات/الكتابات
3. استخدم Cache عند الإمكان
4. راقب حدود الاستخدام المجاني

### للتطوير 🛠️
1. استخدم Test Mode أثناء التطوير
2. اختبر على localhost قبل النشر
3. راجع أخطاء Console
4. استخدم Firebase Emulator للاختبار المحلي

---

## 9️⃣ الموارد الإضافية

### الوثائق الرسمية
- [Firebase Documentation](https://firebase.google.com/docs)
- [Firebase Authentication](https://firebase.google.com/docs/auth/web/start)
- [Realtime Database](https://firebase.google.com/docs/database/web/start)

### الحدود المجانية (Spark Plan)
- **Realtime Database**: 1 GB تخزين، 10 GB تنزيل/شهر
- **Authentication**: غير محدود
- **Hosting**: 10 GB تخزين، 360 MB/يوم

للحصول على مزيد من الموارد، يمكنك الترقية إلى Blaze Plan (الدفع حسب الاستخدام).

---

## 🆘 حل المشاكل الشائعة

### المشكلة: "Permission denied"
**الحل**: تأكد من أن قواعد Firebase Database صحيحة.

### المشكلة: "Network error"
**الحل**: تأكد من أن `databaseURL` صحيح في الإعدادات.

### المشكلة: "Invalid API key"
**الحل**: تأكد من نسخ جميع الإعدادات بشكل صحيح.

### المشكلة: "User not authenticated"
**الحل**: تأكد من تفعيل Email/Password في Authentication.

---

## ✅ قائمة التحقق

- [ ] إنشاء مشروع Firebase
- [ ] تفعيل Authentication (Email/Password)
- [ ] إنشاء Realtime Database
- [ ] نسخ إعدادات Firebase
- [ ] تحديث ملف `js/app.js`
- [ ] رفع الملفات إلى الخادم
- [ ] اختبار التسجيل وتسجيل الدخول
- [ ] التحقق من حفظ البيانات
- [ ] إعداد قواعد الأمان (للإنتاج)
- [ ] إضافة حسابات المسؤولين

---

**تم إنشاء هذا الدليل بواسطة فريق دينار كوين**

في حالة وجود أي مشاكل، يرجى مراجعة الوثائق الرسمية أو الاتصال بالدعم.
