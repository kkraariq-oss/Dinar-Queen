# دينار كوين - Dinar Coin
### العملة الرقمية العراقية الأولى

![Dinar Coin Logo](assets/images/logo.png)

## 📖 نظرة عامة

دينار كوين هو مشروع عملة رقمية تجريبية عراقية تهدف إلى إنشاء عملة رقمية عربية قوية تنافس العملات الرقمية العالمية. هذا المشروع هو نسخة تجريبية (BETA) لاختبار الفكرة والتكنولوجيا.

## ✨ المميزات

### 🎯 المميزات الأساسية
- ✅ نظام مصادقة آمن (تسجيل دخول / إنشاء حساب)
- ✅ محفظة رقمية بتصميم بطاقة ماستركارد
- ✅ نظام إحالة بمكافآت تلقائية
- ✅ شراء العملات (مع موافقة الإدارة)
- ✅ إرسال واستقبال العملات بين المستخدمين
- ✅ QR Code حقيقي لكل مستخدم
- ✅ سجل كامل للمعاملات
- ✅ تصميم متجاوب (Mobile & Desktop)

### 💎 التصميم
- تصميم حديث ومنظم بألوان العلم العراقي
- رسوم متحركة احترافية
- واجهة مستخدم سهلة وجذابة
- قياسات متناسقة على جميع الشاشات

### 🎁 نظام المكافآت
- مكافأة ترحيب: **1.0 DC** عند التسجيل
- مكافأة إحالة: **0.25 DC** لكل 10 إحالات ناجحة
- رمز إحالة فريد لكل مستخدم

## 🚀 التثبيت والإعداد

### المتطلبات الأساسية
- حساب Firebase (مجاني)
- متصفح حديث يدعم ES6
- خادم ويب (أو استضافة GitHub Pages)

### خطوات الإعداد

#### 1. إعداد Firebase

1. اذهب إلى [Firebase Console](https://console.firebase.google.com/)
2. أنشئ مشروع جديد
3. فعّل **Authentication**:
   - اذهب إلى Authentication > Sign-in method
   - فعّل Email/Password
4. فعّل **Realtime Database**:
   - اذهب إلى Realtime Database
   - أنشئ قاعدة بيانات
   - ابدأ في وضع Test mode (للتطوير)

5. احصل على إعدادات Firebase:
   - اذهب إلى Project Settings
   - انسخ إعدادات Firebase Config

#### 2. تحديث الإعدادات

افتح ملف `js/app.js` وحدث إعدادات Firebase:

```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY_HERE",
    authDomain: "YOUR_AUTH_DOMAIN_HERE",
    databaseURL: "YOUR_DATABASE_URL_HERE",
    projectId: "YOUR_PROJECT_ID_HERE",
    storageBucket: "YOUR_STORAGE_BUCKET_HERE",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID_HERE",
    appId: "YOUR_APP_ID_HERE"
};
```

#### 3. إضافة الصور

1. أضف صورة الشعار في: `assets/images/logo.png`
2. أضف صورة الخلفية في: `assets/images/background.jpg`

**ملاحظة**: استخدم نفس أسماء الملفات المذكورة أعلاه، أو قم بتحديث المسارات في الكود.

#### 4. الرفع على GitHub Pages

```bash
# 1. إنشاء repository جديد على GitHub
# 2. رفع الملفات:

git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/dinar-coin.git
git push -u origin main

# 3. تفعيل GitHub Pages:
# اذهب إلى Settings > Pages > Source > main branch
```

## 📁 هيكل المشروع

```
dinar-coin-pro/
│
├── index.html              # الصفحة الرئيسية
│
├── css/
│   └── style.css          # ملف التصميم الرئيسي
│
├── js/
│   └── app.js             # ملف JavaScript الرئيسي
│
├── assets/
│   └── images/
│       ├── logo.png       # شعار دينار كوين
│       └── background.jpg # صورة الخلفية
│
└── README.md              # هذا الملف
```

## 🎨 التخصيص

### تغيير الألوان

عدل متغيرات CSS في ملف `css/style.css`:

```css
:root {
    --primary-green: #1a5f3f;    /* اللون الأخضر الأساسي */
    --dark-green: #0d3d28;       /* اللون الأخضر الداكن */
    --gold: #c9a961;             /* لون الذهب */
    --bright-gold: #FFD700;      /* الذهب الفاتح */
}
```

### تغيير السعر

عدل القيمة في ملف `js/app.js`:

```javascript
const PRICE_PER_COIN = 1000; // سعر العملة بالدينار العراقي
```

### تغيير المكافآت

عدل القيم في ملف `js/app.js`:

```javascript
const WELCOME_BONUS = 1.0;      // مكافأة الترحيب
const REFERRAL_BONUS = 0.25;    // مكافأة الإحالة لكل 10 إحالات
```

## 📱 التوافق

### الأجهزة المدعومة
- ✅ Desktop (1920x1080 وما فوق)
- ✅ Laptop (1366x768 وما فوق)
- ✅ Tablet (768x1024)
- ✅ Mobile (320x568 وما فوق)

### المتصفحات المدعومة
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

## 🔒 الأمان

### قواعد Firebase المقترحة

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid == $uid",
        ".write": "auth != null && auth.uid == $uid"
      }
    },
    "transactions": {
      "$uid": {
        ".read": "auth != null && auth.uid == $uid",
        ".write": "auth != null && auth.uid == $uid"
      }
    },
    "purchase_requests": {
      "$uid": {
        ".read": "auth != null && auth.uid == $uid",
        ".write": "auth != null && auth.uid == $uid"
      }
    }
  }
}
```

## 📊 قاعدة البيانات

### هيكل البيانات

```
firebase-database/
│
├── users/
│   └── {userId}/
│       ├── name: "اسم المستخدم"
│       ├── email: "email@example.com"
│       ├── balance: 1.0
│       ├── referralCode: "DC12345678"
│       ├── referralCount: 0
│       ├── referralEarnings: 0.0
│       ├── usedReferralCode: "DC87654321"
│       └── createdAt: timestamp
│
├── transactions/
│   └── {userId}/
│       └── {transactionId}/
│           ├── type: "buy|sell|send|receive|bonus|referral"
│           ├── amount: 1.0
│           ├── description: "وصف العملية"
│           ├── status: "pending|completed"
│           └── timestamp: timestamp
│
└── purchase_requests/
    └── {userId}/
        └── {requestId}/
            ├── userId: "userId"
            ├── amount: 10.0
            ├── totalIQD: 10000
            ├── status: "pending|approved|rejected"
            └── timestamp: timestamp
```

## 🛠️ التطوير المستقبلي

### قريباً
- [ ] لوحة تحكم للإدارة
- [ ] نظام التعدين
- [ ] تطبيق موبايل (Android/iOS)
- [ ] تكامل مع بوابات الدفع
- [ ] نظام التبادل (Exchange)
- [ ] رفع الصور الشخصية
- [ ] نظام الإشعارات

## 👥 الفريق

فريق من الشباب العراقي المهتمين بالتكنولوجيا والعملات الرقمية.

## 📄 الترخيص

هذا المشروع تجريبي ومفتوح المصدر للأغراض التعليمية.

## 📞 الدعم

للدعم والاستفسارات:
- البريد الإلكتروني: support@dinarcoin.iq (قيد الإنشاء)
- الموقع: https://dinarcoin.github.io (قيد الإنشاء)

## ⚠️ تنبيه مهم

هذا المشروع في مرحلة تجريبية (BETA) ولا يجب استخدامه لأغراض تجارية حقيقية. جميع العمليات المالية في هذا التطبيق هي تجريبية فقط.

---

**صنع بـ ❤️ في العراق**

**دينار كوين - العملة الرقمية العراقية الأولى**
