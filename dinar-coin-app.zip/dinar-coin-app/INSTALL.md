# 🚀 دليل التثبيت السريع - دينار كوين

## الخطوة 1️⃣: رفع المشروع على GitHub

### 1. إنشاء مستودع جديد على GitHub
- اذهب إلى https://github.com/new
- اختر اسم المستودع: `dinar-coin-app`
- اجعله عام (Public)
- لا تضف README أو .gitignore أو license (موجودة بالفعل)
- انقر "Create repository"

### 2. رفع الملفات باستخدام سطر الأوامر

```bash
cd dinar-coin-app
git init
git add .
git commit -m "Initial commit: Dinar Coin App"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/dinar-coin-app.git
git push -u origin main
```

**ملاحظة:** استبدل `YOUR_USERNAME` باسم المستخدم الخاص بك على GitHub

---

## الخطوة 2️⃣: نشر التطبيق على GitHub Pages

### الطريقة الأسهل (من الواجهة):

1. اذهب إلى مستودعك على GitHub
2. انقر على **Settings** (الإعدادات)
3. من القائمة الجانبية، انقر على **Pages**
4. في قسم "Build and deployment":
   - Source: اختر **Deploy from a branch**
   - Branch: اختر **main** → **/ (root)**
   - انقر **Save**
5. انتظر 2-3 دقائق
6. رابط التطبيق سيكون: `https://YOUR_USERNAME.github.io/dinar-coin-app/`

---

## الخطوة 3️⃣: تكوين Firebase

### 1. إنشاء مشروع Firebase
- اذهب إلى https://console.firebase.google.com/
- انقر "Add project" (إضافة مشروع)
- اختر اسم المشروع: `dinar-coin`
- أكمل خطوات الإنشاء

### 2. تفعيل Authentication
- من القائمة الجانبية: **Authentication**
- انقر **Get started**
- من تبويب **Sign-in method**:
  - فعّل **Email/Password**
  - احفظ التغييرات

### 3. تفعيل Realtime Database
- من القائمة الجانبية: **Realtime Database**
- انقر **Create Database**
- اختر الموقع: `us-central1` (أو الأقرب لك)
- ابدأ في وضع **Test mode** مؤقتاً
- انقر **Enable**

### 4. نسخ إعدادات Firebase
- اذهب إلى **Project Settings** (أيقونة الترس)
- في قسم "Your apps":
  - انقر على أيقونة الويب `</>`
  - سجّل التطبيق
  - انسخ كائن `firebaseConfig`

### 5. تحديث الكود
- افتح ملف `app.js`
- ابحث عن السطر الذي يحتوي على `const firebaseConfig`
- استبدل القيم بإعداداتك:

```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID",
    measurementId: "YOUR_MEASUREMENT_ID"
};
```

### 6. إعداد قواعد الأمان
في Realtime Database → Rules، استخدم هذه القواعد:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "referralCodes": {
      ".read": true,
      ".write": true,
      ".indexOn": ["code", "userId"]
    },
    "statistics": {
      ".read": true,
      ".write": "auth != null"
    },
    "buyRequests": {
      "$requestId": {
        ".read": "auth != null",
        ".write": "auth != null"
      }
    }
  }
}
```

---

## الخطوة 4️⃣: تحديث الكود ورفعه

```bash
git add .
git commit -m "Update Firebase configuration"
git push
```

انتظر دقيقة، ثم تفقد رابط التطبيق!

---

## الخطوة 5️⃣: تثبيت التطبيق على الهاتف

### 📱 Android (Chrome):
1. افتح الرابط في Chrome
2. انقر على القائمة (⋮) في الأعلى
3. اختر "إضافة إلى الشاشة الرئيسية"
4. أكمل التثبيت

### 🍎 iOS (Safari):
1. افتح الرابط في Safari
2. انقر على زر المشاركة (المربع مع السهم)
3. اختر "إضافة إلى الشاشة الرئيسية"
4. أكمل التثبيت

### 💻 Windows/Mac (Chrome/Edge):
1. افتح الرابط في المتصفح
2. انقر على أيقونة التثبيت في شريط العنوان
3. أكمل التثبيت

---

## ✅ التحقق من عمل التطبيق

1. افتح التطبيق
2. أنشئ حساب جديد
3. تحقق من وصول بيانات المستخدم إلى Firebase
4. جرّب إرسال واستقبال العملات

---

## 🎯 نصائح مهمة

- ✅ استخدم HTTPS فقط (GitHub Pages يوفره تلقائياً)
- ✅ لا تشارك مفاتيح Firebase API الخاصة بك
- ✅ فعّل قواعد الأمان في Firebase
- ✅ اختبر التطبيق على أجهزة مختلفة
- ✅ راقب استخدام Firebase للتأكد من عدم تجاوز الحد المجاني

---

## 🆘 حل المشاكل الشائعة

### المشكلة: التطبيق لا يفتح على GitHub Pages
**الحل:** تأكد من:
- رفع جميع الملفات
- تفعيل GitHub Pages من الإعدادات
- الانتظار 2-3 دقائق بعد التفعيل

### المشكلة: لا يمكن إنشاء حساب
**الحل:** تأكد من:
- تفعيل Email/Password في Firebase Authentication
- تحديث إعدادات Firebase في الكود
- صحة البريد الإلكتروني وكلمة المرور (6 أحرف على الأقل)

### المشكلة: البيانات لا تحفظ في Firebase
**الحل:** تأكد من:
- تفعيل Realtime Database
- إعداد قواعد الأمان بشكل صحيح
- تحديث رابط Database في الكود

---

## 🎉 تم بنجاح!

الآن أصبح تطبيقك جاهزاً ويعمل!

**رابط التطبيق:** `https://YOUR_USERNAME.github.io/dinar-coin-app/`

شارك الرابط مع أصدقائك وابدأ باستخدام دينار كوين! 🚀

---

**💡 هل تحتاج مساعدة؟**

افتح Issue على GitHub أو راسلنا للحصول على الدعم الفني.
