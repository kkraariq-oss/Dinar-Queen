# دينار كوين - Dinar Coin
## العملة الرقمية العراقية الأولى

![Dinar Coin Logo](logo.png)

### نظرة عامة
دينار كوين هو تطبيق ويب تقدمي (PWA) للعملة الرقمية العراقية الأولى. التطبيق مصمم ليعمل على جميع الأجهزة ويمكن تثبيته على الهواتف المحمولة وأجهزة الكمبيوتر.

---

## ✨ المميزات

- 💰 محفظة رقمية آمنة
- 📊 لوحة تحكم شاملة
- 💸 إرسال واستقبال العملات
- 🎁 نظام الإحالة والمكافآت
- 📱 يعمل على جميع الأجهزة (PWA)
- 🌐 دعم كامل للغة العربية
- 🔒 مصادقة آمنة مع Firebase
- 📈 إحصائيات في الوقت الفعلي
- 🎨 تصميم عصري وجذاب
- 📴 يعمل بدون إنترنت (Offline Support)

---

## 📁 هيكل المشروع

```
dinar-coin-app/
├── index.html              # الصفحة الرئيسية
├── style.css               # ملف التنسيقات
├── app.js                  # الكود البرمجي
├── manifest.json           # ملف PWA Manifest
├── sw.js                   # Service Worker
├── logo.png                # شعار التطبيق
├── background.jpg          # خلفية التطبيق
├── icon-192.png            # أيقونة 192x192
├── icon-512.png            # أيقونة 512x512
├── apple-touch-icon.png    # أيقونة iOS
└── README.md               # هذا الملف
```

---

## 🚀 التثبيت والإعداد

### 1. رفع الملفات على GitHub

#### خطوة 1: إنشاء مستودع جديد
```bash
# في مجلد المشروع
git init
git add .
git commit -m "Initial commit: Dinar Coin App"
```

#### خطوة 2: ربط المستودع بـ GitHub
```bash
# استبدل USERNAME باسم المستخدم الخاص بك
git remote add origin https://github.com/USERNAME/dinar-coin-app.git
git branch -M main
git push -u origin main
```

### 2. نشر التطبيق على GitHub Pages

#### الطريقة الأولى: من صفحة المستودع
1. اذهب إلى Settings → Pages
2. اختر Branch: main
3. اختر المجلد: / (root)
4. انقر Save

#### الطريقة الثانية: تفعيل GitHub Actions
أنشئ ملف `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./
```

### 3. تثبيت التطبيق على الهاتف

#### Android:
1. افتح الرابط في متصفح Chrome
2. انقر على القائمة (⋮)
3. اختر "إضافة إلى الشاشة الرئيسية"
4. اتبع التعليمات لإكمال التثبيت

#### iOS (iPhone/iPad):
1. افتح الرابط في متصفح Safari
2. انقر على أيقونة المشاركة (⎋)
3. اختر "إضافة إلى الشاشة الرئيسية"
4. اتبع التعليمات لإكمال التثبيت

#### Windows/Mac:
1. افتح الرابط في Chrome أو Edge
2. انقر على أيقونة التثبيت في شريط العنوان
3. اتبع التعليمات لإكمال التثبيت

---

## 🔧 الإعدادات المطلوبة

### تكوين Firebase

1. أنشئ مشروع جديد في [Firebase Console](https://console.firebase.google.com/)
2. فعّل خدمة Authentication → Email/Password
3. فعّل Realtime Database
4. انسخ إعدادات Firebase من Project Settings
5. استبدل الإعدادات في ملف `app.js`:

```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID",
    measurementId: "YOUR_MEASUREMENT_ID"
};
```

### قواعد Realtime Database

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "statistics": {
      ".read": true,
      ".write": false
    }
  }
}
```

---

## 📱 كيفية الاستخدام

### إنشاء حساب جديد
1. افتح التطبيق
2. انقر على "إنشاء حساب"
3. أدخل بياناتك (الاسم، البريد، كلمة المرور)
4. اختياري: أدخل رمز الإحالة
5. انقر "إنشاء الحساب"

### تسجيل الدخول
1. انقر على "تسجيل الدخول"
2. أدخل البريد وكلمة المرور
3. انقر "تسجيل الدخول"

### شراء العملات
1. من لوحة التحكم، انقر على "شراء"
2. أدخل الكمية المطلوبة
3. انقر "إرسال الطلب"
4. انتظر موافقة الإدارة

### إرسال العملات
1. انقر على "إرسال"
2. أدخل رمز إحالة المستلم
3. أدخل الكمية
4. اختياري: أضف ملاحظة
5. انقر "إرسال"

### استقبال العملات
1. انقر على "استقبال"
2. شارك رمز الإحالة أو QR Code مع المرسل

---

## 🎨 تخصيص التطبيق

### تغيير الألوان
في ملف `style.css`، عدّل المتغيرات:

```css
:root {
    --primary-color: #1a5f4a;      /* اللون الأساسي */
    --secondary-color: #d4af37;     /* اللون الثانوي */
    --background: #0a1f1a;          /* لون الخلفية */
}
```

### تغيير الشعار
استبدل الملفات:
- `logo.png` (الشعار الرئيسي)
- `icon-192.png` و `icon-512.png` (أيقونات PWA)
- `apple-touch-icon.png` (أيقونة iOS)

### تغيير الخلفية
استبدل ملف `background.jpg` بصورة جديدة

---

## 🔐 الأمان

- جميع كلمات المرور مشفرة بواسطة Firebase Auth
- البيانات محمية بقواعد Realtime Database
- HTTPS إلزامي للإنتاج
- Service Worker يعمل فقط على HTTPS

---

## 🌐 نشر التطبيق

### GitHub Pages (مجاني)
```
https://USERNAME.github.io/dinar-coin-app/
```

### Netlify (مجاني)
1. اربط مستودع GitHub
2. Deploy تلقائي عند كل push

### Vercel (مجاني)
1. استورد المشروع من GitHub
2. Deploy فوري

### استضافة مخصصة
1. ارفع جميع الملفات
2. تأكد من دعم HTTPS
3. تأكد من الإعدادات الصحيحة

---

## 📊 الإحصائيات

التطبيق يعرض إحصائيات في الوقت الفعلي:
- عدد المستخدمين النشطين
- عدد العمليات المتاحة
- إجمالي المعاملات الناجحة

---

## 🐛 استكشاف الأخطاء

### المشكلة: التطبيق لا يعمل على الهاتف
**الحل:**
- تأكد من استخدام HTTPS
- امسح ذاكرة المتصفح المؤقتة
- أعد تحميل الصفحة

### المشكلة: لا يمكن إنشاء حساب
**الحل:**
- تحقق من إعدادات Firebase
- تأكد من تفعيل Email/Password في Authentication
- تحقق من صحة البريد الإلكتروني

### المشكلة: الصور لا تظهر
**الحل:**
- تأكد من رفع جميع الملفات
- تحقق من المسارات في الكود
- افحص Console في المتصفح

---

## 📞 الدعم الفني

لأي استفسارات أو مشاكل:
- افتح Issue على GitHub
- راسلنا على البريد الإلكتروني
- انضم إلى مجتمعنا

---

## 📄 الترخيص

هذا المشروع مرخص تحت MIT License

---

## 🙏 شكر وتقدير

شكراً لاستخدامك دينار كوين!

**صُنع بـ ❤️ في العراق 🇮🇶**

---

## 🔄 التحديثات القادمة

- [ ] إضافة محفظة متعددة العملات
- [ ] تكامل مع بوابات الدفع
- [ ] نظام الإشعارات Push
- [ ] التحقق بخطوتين (2FA)
- [ ] تطبيقات أصلية لـ Android/iOS
- [ ] API للمطورين

---

**الإصدار:** 1.0.0 BETA  
**تاريخ الإصدار:** فبراير 2026  
**آخر تحديث:** 2026-02-06
